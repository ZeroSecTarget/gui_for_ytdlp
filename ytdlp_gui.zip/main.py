from ui.main_window import start_gui

if __name__ == "__main__":
    start_gui()

import subprocess
import threading

def run_ytdlp_command(cmd: list, callback):
    def run():
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        for line in process.stdout:
            callback(line)
        process.wait()
    thread = threading.Thread(target=run)
    thread.start()

def build_ytdlp_command(url: str, options: dict) -> list:
    cmd = ["yt-dlp"]
    fmt = options.get("format", "best")
    output = options.get("output", "%(title)s.%(ext)s")

    cmd += ["-f", fmt, "-o", output, url]
    return cmd

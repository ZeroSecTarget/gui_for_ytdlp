import tkinter as tk
from tkinter import ttk, filedialog
from core.command_builder import build_ytdlp_command
from core.runner import run_ytdlp_command

def start_gui():
    root = tk.Tk()
    root.title("yt-dlp GUI")
    root.geometry("600x400")

    url_var = tk.StringVar()
    format_var = tk.StringVar(value="best")
    output_path_var = tk.StringVar(value="%(title)s.%(ext)s")

    def browse_output():
        path = filedialog.askdirectory()
        if path:
            output_path_var.set(f"{path}/%(title)s.%(ext)s")

    def log_callback(line):
        log_text.configure(state='normal')
        log_text.insert(tk.END, line)
        log_text.see(tk.END)
        log_text.configure(state='disabled')

    def start_download():
        cmd = build_ytdlp_command(url_var.get(), {
            "format": format_var.get(),
            "output": output_path_var.get()
        })
        log_text.configure(state='normal')
        log_text.delete(1.0, tk.END)
        log_text.configure(state='disabled')
        run_ytdlp_command(cmd, log_callback)

    tk.Label(root, text="Video URL:").pack(anchor='w')
    tk.Entry(root, textvariable=url_var, width=80).pack(fill='x', padx=5)

    tk.Label(root, text="Format:").pack(anchor='w')
    ttk.Combobox(root, textvariable=format_var, values=["best", "bestaudio", "bestvideo"]).pack(fill='x', padx=5)

    tk.Label(root, text="Output Path:").pack(anchor='w')
    path_frame = tk.Frame(root)
    path_frame.pack(fill='x', padx=5)
    tk.Entry(path_frame, textvariable=output_path_var, width=60).pack(side='left', fill='x', expand=True)
    tk.Button(path_frame, text="Browse", command=browse_output).pack(side='left')

    tk.Button(root, text="Download", command=start_download).pack(pady=10)

    log_text = tk.Text(root, height=10, state='disabled')
    log_text.pack(fill='both', expand=True, padx=5, pady=5)

    root.mainloop()

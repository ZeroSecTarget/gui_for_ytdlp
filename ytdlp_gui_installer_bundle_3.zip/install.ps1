
# ======================= install.ps1 =======================
# One-click installer for GUI_for_ytdlp
# Checks/Installs: Python, yt-dlp, ffmpeg, GUI
# Author: GPT
# ===========================================================

$ErrorActionPreference = "Stop"

function Write-Log {
    param([string]$msg)
    Write-Host "[$(Get-Date -Format HH:mm:ss)] $msg"
}

# Prompt user for installation path
$defaultPath = "$env:LOCALAPPDATA\YTDLP-GUI"
$Shell = New-Object -ComObject Shell.Application
$folder = $Shell.BrowseForFolder(0, "Select installation folder for GUI_for_ytdlp", 0, $defaultPath)
if (-not $folder) { Write-Host "Cancelled."; exit }
$installPath = $folder.Self.Path

# Create install path if missing
if (-not (Test-Path $installPath)) {
    New-Item -ItemType Directory -Path $installPath | Out-Null
}

# ------------------------- Check Python -------------------------
function Install-Python {
    Write-Log "Downloading Python..."
    $pythonInstaller = "$env:TEMP\python_installer.exe"
    Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.12.2/python-3.12.2-amd64.exe" -OutFile $pythonInstaller
    Write-Log "Installing Python..."
    Start-Process -Wait -FilePath $pythonInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1 Include_test=0"
    Remove-Item $pythonInstaller
}

Write-Log "Checking for Python..."
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Install-Python
} else {
    Write-Log "Python is already installed."
}

# Refresh session
$env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")

# ------------------------- Check yt-dlp -------------------------
Write-Log "Checking for yt-dlp..."
if (-not (python -m yt_dlp --version 2>$null)) {
    Write-Log "Installing yt-dlp via pip..."
    python -m pip install --upgrade pip
    python -m pip install yt-dlp
} else {
    Write-Log "yt-dlp is already installed."
}

# ------------------------- Check ffmpeg -------------------------
$ffmpegPath = "$env:LOCALAPPDATA\ffmpeg\bin"
$ffmpegExe = Join-Path $ffmpegPath "ffmpeg.exe"

function Install-FFmpeg {
    Write-Log "Downloading ffmpeg..."
    $zipPath = "$env:TEMP\ffmpeg.zip"
    Invoke-WebRequest -Uri "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip" -OutFile $zipPath
    Expand-Archive -Path $zipPath -DestinationPath "$env:TEMP\ffmpeg" -Force
    $src = Get-ChildItem "$env:TEMP\ffmpeg" -Directory | Select-Object -First 1
    Copy-Item "$($src.FullName)\bin" -Destination "$env:LOCALAPPDATA\ffmpeg" -Recurse -Force
    Remove-Item $zipPath
}

if (-not (Test-Path $ffmpegExe)) {
    Install-FFmpeg
} else {
    Write-Log "ffmpeg is already installed."
}

# Ensure ffmpeg path in user PATH
$pathUser = [System.Environment]::GetEnvironmentVariable("Path", "User")
if ($pathUser -notlike "*$ffmpegPath*") {
    Write-Log "Adding ffmpeg to PATH..."
    [Environment]::SetEnvironmentVariable("Path", "$pathUser;$ffmpegPath", "User")
}

# ------------------------- Install GUI -------------------------
$guiZip = "ytdlp_gui.zip"
$guiZipPath = Join-Path $PSScriptRoot $guiZip
$downloadUrl = "https://github.com/yourusername/ytdlp_gui/archive/refs/heads/main.zip"

if (Test-Path $guiZipPath) {
    Write-Log "Extracting local GUI zip..."
    Expand-Archive -Path $guiZipPath -DestinationPath $installPath -Force
} else {
    Write-Log "GUI zip not found. Downloading from GitHub..."
    $tmpZip = "$env:TEMP\gui_download.zip"
    Invoke-WebRequest -Uri $downloadUrl -OutFile $tmpZip
    Expand-Archive -Path $tmpZip -DestinationPath $installPath -Force
    Remove-Item $tmpZip
}

# ------------------------- Create Shortcut -------------------------
$mainScript = Join-Path $installPath "main.py"
$shortcutPath = "$env:USERPROFILE\Desktop\GUI_for_ytdlp.lnk"

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = "python"
$shortcut.Arguments = "`"$mainScript`""
$shortcut.WorkingDirectory = $installPath
$shortcut.IconLocation = "$ffmpegExe"
$shortcut.Save()

Write-Log "Installation complete. Shortcut created on Desktop: GUI_for_ytdlp"
